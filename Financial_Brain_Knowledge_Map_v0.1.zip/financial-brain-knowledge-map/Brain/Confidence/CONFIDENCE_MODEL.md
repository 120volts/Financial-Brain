# Confidence Model

Confidence is structured, not a feeling.

## Dimensions

Evidence confidence, entity-match confidence, classification confidence, rule-applicability confidence, calculation confidence, source-currentness confidence, and overall conclusion confidence.

## Labels

- Confirmed: authoritative or user-confirmed with no material conflict.
- High: strong evidence and clear rule; remaining uncertainty does not change the result.
- Medium: plausible, but missing facts could materially change it.
- Low: insufficient or conflicting evidence.
- Unknown: not enough information.

Never average away a critical unknown. A strong invoice match cannot compensate for an unknown business-use percentage when that percentage controls the deduction.

Recommend enhanced or professional review for ambiguity, unusual facts, large amounts, multiple jurisdictions, related parties, weak evidence, difficult-to-reverse elections, or legal characterization beyond routine preparation.
