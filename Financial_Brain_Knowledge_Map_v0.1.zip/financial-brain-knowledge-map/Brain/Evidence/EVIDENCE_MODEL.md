# Evidence Model

Evidence is what the system observed or received. A conclusion is what the system believes it means.

## Evidence object

```yaml
evidence_id:
evidence_type:
source_module:
source_system:
source_record_id:
captured_at:
effective_date:
tax_year:
original_payload_hash:
original_file_reference:
extracted_fields:
owner:
business:
account:
client:
project:
counterparty:
amount:
currency:
location:
status:
quality:
created_by:
supersedes:
notes:
```

## Evidence types

Invoice, invoice line, estimate, payment, bank transaction, card transaction, receipt, purchase order, contract, calendar event, mileage record, location record, email, payroll record, tax form, tax return, IRS notice, brokerage record, retirement record, asset record, loan record, user statement, professional statement, and calculated record.

## Fact object

```yaml
fact_id:
fact_type:
subject:
value:
effective_period:
tax_year:
status:
confidence:
supporting_evidence:
contradicting_evidence:
assumptions:
created_by_rule:
last_recomputed_at:
user_confirmed:
```

## Conclusion object

```yaml
conclusion_id:
conclusion_type:
tax_year:
facts_used:
rule_version:
calculation_version:
result:
alternatives:
confidence:
sources:
review_status:
user_decision:
```

## Contradictions

Retain all evidence, identify conflict, rank source quality, ask the smallest necessary question, document the resolution, preserve prior conclusions, and recompute downstream results.

A $4,550 deposit could be client payment, transfer, owner contribution, loan proceeds, refund, asset sale, taxable income, or another receipt. Context must decide.
