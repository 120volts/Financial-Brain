# Tax Ontology

## Core entities

Taxpayer, household, business, entity, tax year, jurisdiction, return, form, schedule, line, worksheet, election, income item, expense item, asset, liability, account, transaction, payment, credit, deduction, adjustment, exclusion, deferral, carryover, basis, limitation, phaseout, threshold, deadline, penalty, evidence requirement, authority, and planning opportunity.

## Rule object

```yaml
rule_id:
name:
jurisdiction:
tax_years:
topic:
rule_type:
eligibility_conditions:
exclusions:
inputs:
calculation:
limits:
phaseouts:
elections:
deadline:
required_evidence:
interactions:
outputs:
form_destinations:
source_citations:
tests:
review_level:
```

## Form mapping

```yaml
form_id:
revision_year:
form_name:
purpose:
taxpayer_types:
inputs:
outputs:
lines:
worksheets:
attachments:
dependencies:
validation_rules:
official_sources:
```

## Example relationship

```text
BusinessPurchase
  may_be → CurrentExpense
  may_be → CapitalAsset
  may_require → Depreciation
  may_allow → Election
  may_have → BusinessUsePercentage
  affects → NetProfit
  affects → SelfEmploymentTax
  affects → OtherTaxCalculations
```

## Benefit taxonomy

Exclusions, deductions, adjustments, credits, deferrals, basis recovery, depreciation and expensing, retirement contributions, income and expense timing, entity and payroll choices, carryovers, elections, safe harbors, de minimis rules, reimbursements, loss utilization, estimated-payment optimization, and state-specific benefits.

Every benefit record must also identify costs, restrictions, evidence, interactions, deadlines, and future consequences.
