# Tax Topic Template

## Identity

- Topic name
- Topic ID
- Jurisdiction
- Applicable tax years
- Status
- Last reviewed
- Knowledge version

## Plain-language summary

## Policy purpose

## Eligibility

- Required conditions
- Disqualifying conditions
- Facts to confirm
- Facts that may be inferred

## Inputs

| Input | Type | Required | Source | Tax-year specific |
|---|---|---:|---|---:|

## Evidence

Strong evidence, supporting evidence, weak evidence, and missing-evidence warning.

## Calculation

Formula or algorithm, rounding, ordering, caps, phaseouts, carryovers, and worksheet dependencies.

## Alternatives and elections

For each: benefit, downside, cash-flow impact, future-year impact, deadline, revocability, documentation, and interactions.

## Form flow

```text
Source event → fact → worksheet → form/schedule line → return
```

## Questions Financial Brain may ask

Each question includes exact wording, why it matters, branches changed, whether it can be skipped, and accepted answers.

## Opportunity triggers and alerts

Deadlines, missing evidence, threshold proximity, inconsistent records, likely opportunity, lost opportunity, and professional-review recommendation.

## Explanation

Plain language, technical detail, assumptions, confidence, and exact sources.

## Examples and tests

Qualifying, nonqualifying, mixed-use, incomplete-evidence, interaction, prior-year/current-year, boundary, phaseout, missing-input, conflicting-evidence, source-change, and user-override cases.
