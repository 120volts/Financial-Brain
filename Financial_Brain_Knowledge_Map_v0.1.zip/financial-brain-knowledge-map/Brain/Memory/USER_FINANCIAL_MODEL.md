# User Financial Model

Store durable facts needed for reasoning, each with an effective date, source, confidence, last confirmation, and supersession history.

## Categories

- Identity, household, filing status, and residency history
- Businesses, entities, ownership, accounting method, industry, clients, vendors, reimbursements
- Bank, card, retirement, brokerage, loan, and payment accounts
- Vehicles, equipment, real estate, acquisition date, basis, business-use history, and disposition
- Prior returns, carryovers, depreciation, elections, estimated payments, notices, and unresolved issues
- Notification preferences, explanation depth, review thresholds, and risk preference

Memory is not permanent truth. It is versioned evidence-backed context.
