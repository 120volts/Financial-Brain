# Reasoning Engine

## AI responsibilities

Document interpretation, merchant understanding, relationship discovery, ambiguity detection, question generation, explanation, summarization, candidate classification, and identifying potentially relevant concepts.

## Deterministic-code responsibilities

Arithmetic, thresholds, phaseouts, tax tables, form calculations, depreciation schedules, carryforwards, basis, date rules, allocations, validation, and reconciliation.

## User-approval responsibilities

Uncertain business purpose, material classification changes, tax elections, uncertain filing positions, destructive changes, and final filing.

## Pipeline

```text
Observe event
→ preserve evidence
→ extract fields
→ normalize entities
→ match records
→ produce candidate facts
→ test contradictions
→ find relevant knowledge
→ apply tax-year rules
→ calculate outcomes
→ compare alternatives
→ identify missing facts
→ assign confidence
→ explain
→ ask only necessary questions
→ obtain decision
→ update projections
→ preserve audit trail
```

## Question rule

Ask only when the answer materially changes classification, eligibility, calculation, filing, or risk and cannot be inferred reliably. Explain why the question matters.

## Opportunity triggers

New income, projected income changes, asset purchases, retirement capacity, deadlines, carryforwards, credit eligibility, estimated-payment shortages, timing choices, household changes, residency changes, business use of home or vehicle, health insurance, capital gains or losses, and charitable activity.

## Scenario comparison

Show current-year effect, future-year effect, required cash, liquidity, compliance burden, documentation, deadlines, reversibility, uncertainty, and interactions.

Every conclusion must be reproducible as:

```text
Evidence → Facts → Rule → Calculation → Result
```
