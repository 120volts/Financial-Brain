# Tax Source Policy

Tax rules are versioned by tax year and effective date. Preserve the exact source used for every material conclusion.

## Source hierarchy

1. Statutes and enacted law
2. Treasury regulations
3. Applicable court decisions
4. IRS forms and official instructions
5. IRS revenue rulings, revenue procedures, notices, and announcements
6. IRS publications and official topic pages
7. State statutes, regulations, forms, instructions, and official guidance
8. Professional secondary explanations
9. Informal material only as a discovery lead

IRS publications and web pages are useful explanations, but the system should distinguish explanatory guidance from controlling authority.

## Source record

```yaml
source_id:
jurisdiction:
authority_type:
title:
issuing_body:
tax_year:
published_date:
effective_start:
effective_end:
retrieved_at:
version:
official_url:
local_snapshot:
content_hash:
supersedes:
topics:
forms:
citations:
```

## Ingestion

Acquire official source → preserve original → extract structure → identify years and dates → map forms and concepts → create interpreted records → quality review → publish knowledge version → run regression tests.

## Updates

Diff previous version, list affected topics and calculations, identify affected users and years, run tests, recompute where appropriate, and explain what changed.

Every material recommendation must cite the exact source version used.
