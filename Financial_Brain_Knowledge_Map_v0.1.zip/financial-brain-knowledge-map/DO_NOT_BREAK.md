# Do Not Break

1. Keep raw evidence separate from interpretation.
2. Never silently overwrite original evidence.
3. Never permanently delete financial evidence without explicit action and an audit trail.
4. Never classify a deposit as income solely because money entered an account.
5. Never classify a withdrawal as expense solely because money left an account.
6. Never treat an invoice as paid income without payment evidence or accounting-method support.
7. Never fabricate business purpose, eligibility, basis, mileage, dates, or documentation.
8. Never recommend a tax position without identifying required facts.
9. Never apply rules to the wrong tax year.
10. Never present an estimate as a filed or final result.
11. Never hide assumptions or uncertainty.
12. Never silently choose between materially different tax elections.
13. Never optimize tax savings while ignoring cash flow, future effects, compliance, risk, or goals.
14. Never ask for information that can be reliably inferred.
15. Never make a consequential inference when user confirmation is required.
16. Every recommendation must trace to evidence, rules, calculations, and sources.
17. UI refactors must not change financial calculations without tests.
18. Never break compatibility with existing invoices or records without migration.
19. AI may interpret and explain; deterministic code must perform tax arithmetic.
20. Final filing and material elections require user approval.
