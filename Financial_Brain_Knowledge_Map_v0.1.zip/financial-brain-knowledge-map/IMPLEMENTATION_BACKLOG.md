# Implementation Backlog

## Immediate

- [ ] Add `AGENTS.md` requiring AI tools to read this map first.
- [ ] Add the map to the main Financial Brain repository.
- [ ] Record the architecture decision: modules are sensors; the Brain owns interpretation.
- [ ] Define canonical financial events, IDs, linking rules, immutable evidence, tax-year versioning, source snapshots, rule versions, and correction workflows.

## First tax topics

- [ ] Gross receipts and payment matching
- [ ] Schedule C expense classification
- [ ] Business versus personal expense
- [ ] Transfers, loans, owner contributions, and refunds
- [ ] Meals, travel, mileage, and vehicles
- [ ] Equipment versus supplies and depreciation choices
- [ ] Home office
- [ ] Self-employment tax and estimated taxes
- [ ] Retirement and health-insurance planning
- [ ] Information-return reconciliation
- [ ] Basis, asset disposition, recordkeeping, and substantiation

## First reasoning prototypes

1. Match invoice to payment.
2. Distinguish income from transfer or loan.
3. Link purchase to project.
4. Detect possible business asset.
5. Detect possible business trip.
6. Update year-to-date profit and tax projection.
7. Produce a recommendation with evidence and missing facts.
8. Show exactly how the conclusion flows to a form.
9. Recompute after correction without deleting history.

## First acceptance test

Given a calendar job, invoice, matching deposit, related equipment receipt, and mileage record, Financial Brain should connect them to one project, identify likely income, flag possible asset treatment and mileage, update projections, show unresolved questions, explain every conclusion, preserve evidence separately, and make no election or filing decision without approval.
