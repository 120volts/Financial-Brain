# Financial Brain Knowledge Map

## 1. Brain architecture

```text
Brain/
├── Knowledge/
│   ├── Tax/
│   ├── Accounting/
│   ├── Business/
│   ├── PersonalFinance/
│   ├── Retirement/
│   ├── Insurance/
│   ├── Investing/
│   └── StateAndLocal/
├── Evidence/
├── Reasoning/
├── Rules/
├── Memory/
├── Sources/
├── Confidence/
├── Explanations/
├── Calculations/
├── Scenarios/
└── AuditTrail/
```

## 2. Tax knowledge domains

```text
Tax/
├── TaxYears/
├── TaxpayerProfiles/
├── FilingStatus/
├── Dependents/
├── Income/
├── BusinessIncome/
├── Adjustments/
├── ItemizedDeductions/
├── BusinessDeductions/
├── Credits/
├── AssetsAndDepreciation/
├── VehiclesAndMileage/
├── HomeOffice/
├── TravelMealsAndEntertainment/
├── Retirement/
├── HealthCoverage/
├── Investments/
├── CapitalGainsAndLosses/
├── PassiveActivities/
├── RealEstate/
├── EstimatedTaxes/
├── SelfEmploymentTax/
├── Payroll/
├── InformationReturns/
├── EntitySelection/
├── Elections/
├── Carryovers/
├── LimitationsAndPhaseouts/
├── Basis/
├── AtRiskRules/
├── Recordkeeping/
├── PenaltiesAndInterest/
├── AuditAndSubstantiation/
├── FederalForms/
├── StateReturns/
└── TaxPlanning/
```

Every topic must define: purpose, eligibility, disqualifiers, required facts, evidence, tax years, thresholds, elections, tradeoffs, interactions, forms and lines, questions to ask, inferences allowed, user confirmations, substantiation risk, sources, and facts that would change the answer.

## 3. Modules are sensors

### Invoice
Evidence of work performed, client, project, service dates, amounts billed, payment terms, expected income, payment status, receivables, and business activity.

### Purchases and receipts
Evidence of vendor, item, amount, business purpose, project, account, sales tax, possible asset treatment, warranty, and useful life.

### Banking
Evidence of cash movement, settlement, transfers, fees, interest, debt payments, merchant patterns, and missing or duplicate records. A deposit is not automatically income, and a withdrawal is not automatically an expense.

### Calendar
Evidence of work dates, meetings, travel, job locations, project duration, business purpose, and timing relationships.

### Mileage and location
Evidence of trip date, origin, destination, distance, purpose, client or project, commuting exclusion, and contemporaneous records.

### Documents
W-2, 1099 series, K-1, brokerage statements, mortgage statements, property-tax records, retirement forms, insurance forms, prior returns, notices, contracts, receipts, and loan documents.

### Communications
Future evidence from email, client messages, confirmations, bookings, contracts, and purchase messages. Communications may support conclusions but should not silently create irreversible records.

## 4. Normalized facts

```yaml
fact_id: fact-payment-001
fact_type: PaymentReceived
amount: 3100
currency: USD
date: 2026-05-20
payer: Think Global Media Group LLC
matched_invoice: INV-2026-041
account: Business Checking
confidence: 0.98
evidence:
  - bank_transaction_8832
  - invoice_INV-2026-041
```

## 5. Relationship graph

```text
Person → owns → Business
Business → serves → Client
Business → performs → Project
Project → creates → Invoice
Invoice → may_match → Payment
Project → causes → Purchase
Project → requires → Trip
Evidence → supports/contradicts → Fact
Fact → contributes_to → AccountingConclusion
Fact → contributes_to → TaxConclusion
TaxConclusion → may_trigger → PlanningOpportunity
```

## 6. Outputs

- current income and deductible-expense estimates;
- estimated taxable profit and self-employment tax;
- estimated federal and state liability;
- estimated-payment status;
- year-end projection;
- receivables and cash-flow forecast;
- missing-evidence alerts;
- possible deductions, credits, elections, or asset treatments;
- retirement scenarios;
- form-ready values;
- audit-support package;
- explanation of every conclusion.

## 7. Recommendation contract

Every recommendation includes: action, expected benefit, downsides, tax year, eligibility, evidence, missing facts, assumptions, confidence, sources, calculation, alternatives, deadline, review level, and user decision.

## 8. Lawful opportunity engine

Financial Brain may identify lawful deductions, credits, elections, safe harbors, timing choices, entity choices, and planning strategies. It must never invent expenses, conceal income, manufacture business purpose, create false documents, or treat uncertainty as certainty.

## 9. Build order

1. Evidence foundation
2. Tax ontology and source versioning
3. Deterministic calculation and reasoning engine
4. Continuous year-round planning
5. Filing support and audit package
