# Invoice as a Sensor

The Invoice module is one input channel to Financial Brain.

## It captures

Client, project, work description, service date, location, quantity, rate, reimbursable expenses, payment terms, status, expected payment, actual-payment match, attachments, and notes.

## It triggers

Expected-income projection, receivables, client and project records, calendar cross-check, related-purchase search, mileage search, payment matching, estimated-tax updates, information-return reconciliation, and missing-evidence review.

## It does not assume

An issued invoice is paid; payment date equals service date; every amount is taxable income; reimbursements are income without analysis; one client equals one business; or all work belongs to one tax year.

The module should collect context naturally without turning invoice creation into a tax interview.
