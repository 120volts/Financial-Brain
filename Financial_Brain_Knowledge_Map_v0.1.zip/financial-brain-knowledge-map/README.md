# Financial Brain Knowledge Map

Financial Brain is a year-round financial reasoning system. It collects evidence as financial events occur, maintains a continuously updated understanding of the user, identifies lawful tax-planning opportunities, and explains its conclusions.

> **Financial Brain should know what happened during the year, not try to reconstruct it after the year is over.**

## Core flow

Real-world event → evidence → normalized fact → accounting interpretation → tax interpretation → planning opportunity → recommendation → user approval → filing or action.

## Start here

1. `KNOWLEDGE_MAP.md`
2. `Brain/Evidence/EVIDENCE_MODEL.md`
3. `Brain/Reasoning/REASONING_ENGINE.md`
4. `Brain/Sources/SOURCE_POLICY.md`
5. `Brain/Knowledge/Tax/TAX_ONTOLOGY.md`
6. `Brain/Knowledge/Tax/TAX_TOPIC_TEMPLATE.md`
7. `Brain/Confidence/CONFIDENCE_MODEL.md`
8. `DO_NOT_BREAK.md`

Evidence and conclusions must remain separate so conclusions can be recomputed when facts, documents, tax rules, or tax years change.
