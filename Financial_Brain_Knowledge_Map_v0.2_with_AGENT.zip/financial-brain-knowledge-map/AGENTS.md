# AGENTS.md — Financial Brain Operating Agent

Read this document before changing any code, schema, user interface, workflow, calculation, or knowledge file.

This document defines what Financial Brain is, how it must reason, and what must never be lost as the project grows.

---

## 1. What Financial Brain Is

Financial Brain is not primarily:

- an invoice application;
- a bookkeeping application;
- a tax-return application;
- a receipt organizer;
- a banking dashboard;
- a budgeting application;
- an AI chat interface.

Those may exist as modules.

Financial Brain is a **continuous financial-state system**.

It maintains an evolving representation of the user’s financial reality as events happen throughout the year.

Its purpose is not merely to report what already happened.

Its purpose is to remain current enough to:

- understand what is happening now;
- calculate the effects while decisions can still be changed;
- identify missing evidence before it is forgotten;
- recognize financial and tax consequences early;
- project what is likely to happen next;
- present meaningful choices before deadlines pass;
- make taxes and reporting the result of work already completed during the year.

The central architectural truth is:

> Financial Brain continuously updates the user’s financial state as new evidence arrives.

---

## 2. The Main Advantage

Traditional accountants, tax preparers, and financial software often receive incomplete information after the fact.

By then:

- context has been forgotten;
- receipts are missing;
- business purpose is unclear;
- tax-planning windows have closed;
- invoices and deposits are difficult to match;
- mileage and travel records must be reconstructed;
- equipment decisions can no longer be timed;
- retirement and estimated-tax decisions may be too late.

Financial Brain must not operate this way.

Its advantage is **continuous context**.

It should know during the year:

- what work was performed;
- who the client was;
- when the work occurred;
- what was invoiced;
- when payment was expected;
- when payment arrived;
- what purchases were related;
- which project caused the purchase;
- whether travel occurred;
- what assets were acquired;
- how cash flow changed;
- how estimated taxes changed;
- what decisions remain available.

Founding principle:

> Financial Brain should know what happened during the year, not try to reconstruct it after the year is over.

---

## 3. The Continuous-State Model

Every meaningful event updates the financial state.

```text
Real-world event
        ↓
Evidence captured
        ↓
Entities identified
        ↓
Facts proposed
        ↓
Relationships updated
        ↓
Financial state recalculated
        ↓
Accounting effects calculated
        ↓
Tax effects calculated
        ↓
Forecasts updated
        ↓
Opportunities and risks evaluated
        ↓
User informed when action matters
```

Examples of state-changing events:

- an invoice is created;
- a client views an invoice;
- a payment arrives;
- a purchase is made;
- a receipt is uploaded;
- a calendar job is added;
- mileage is recorded;
- equipment is placed in service;
- a bank transaction is imported;
- a tax form arrives;
- a retirement contribution is made;
- a tax law or threshold changes;
- the user corrects a classification.

The system must recalculate downstream effects after each material event.

---

## 4. Modules Are Sensors and Interfaces

Modules do not own financial truth.

They contribute evidence to the shared financial state or present outputs derived from it.

### Invoice module

The Invoice module captures:

- client;
- project;
- service date;
- work description;
- rate;
- amount billed;
- payment terms;
- expected income;
- reimbursement details;
- supporting attachments.

It may trigger:

- accounts-receivable updates;
- income projections;
- payment matching;
- calendar matching;
- mileage checks;
- purchase matching;
- estimated-tax recalculation.

It must not assume an invoice is paid merely because it exists.

### Purchases and receipts

These capture evidence about:

- vendor;
- date;
- amount;
- item or service;
- project;
- business purpose;
- asset possibility;
- payment account;
- warranty or useful-life data.

They must not automatically become deductions.

### Banking

Bank records show movement of money.

They do not automatically prove:

- income;
- expense;
- business purpose;
- ownership;
- taxability.

A deposit may be income, transfer, loan proceeds, owner contribution, refund, reimbursement, or asset-sale proceeds.

### Calendar

Calendar records may support:

- work dates;
- project identity;
- business purpose;
- travel;
- mileage;
- location;
- service period.

They are supporting evidence, not unquestionable truth.

### Tax module

The Tax module reads the current financial state.

It should not become a separate silo that asks the user to reconstruct information already available elsewhere.

---

## 5. The Core Separation

The following must remain separate:

```text
Evidence
Facts
Relationships
Conclusions
Recommendations
User decisions
Filed results
```

### Evidence

What the system observed or received.

Examples:

- receipt image;
- bank transaction;
- invoice;
- calendar event;
- mileage record;
- tax form;
- user statement.

### Fact

A normalized claim supported by evidence.

Example:

> Payment of $3,100 received from Client A on May 20.

### Relationship

How facts connect.

Example:

> Payment relates to Invoice 1042, Project 221, and Client A.

### Conclusion

What the system believes the facts mean under a rule.

Example:

> This payment appears to be Schedule C gross receipts for tax year 2026.

### Recommendation

A possible action based on the current state.

Example:

> Increase the next estimated-tax payment because projected annual profit has increased.

### User decision

What the user approves, rejects, or corrects.

### Filed result

What was ultimately submitted or formally recorded.

Never merge these layers into one irreversible record.

---

## 6. Evidence Must Survive Changing Interpretations

Evidence is preserved.

Interpretations may change.

A conclusion may change because:

- the user corrects a fact;
- a better match is discovered;
- a missing document arrives;
- the accounting method changes;
- a different tax year applies;
- a law changes;
- a source is superseded;
- professional review reaches another conclusion.

When a conclusion changes:

1. preserve the original evidence;
2. preserve the prior conclusion;
3. record why the conclusion changed;
4. identify the new rule or evidence;
5. recompute all affected outputs;
6. retain the audit trail.

Do not silently overwrite history.

---

## 7. The Agent’s Responsibilities

Whenever working on Financial Brain, determine which of these jobs is being performed:

### A. Evidence capture

Improve how reliable information enters the system.

### B. Entity resolution

Identify people, businesses, clients, vendors, accounts, projects, assets, and documents.

### C. Relationship building

Connect records that describe the same real-world event.

### D. Financial-state calculation

Update income, expenses, assets, liabilities, cash flow, receivables, tax estimates, and forecasts.

### E. Knowledge application

Apply accounting, tax, business, or planning knowledge to the known facts.

### F. Opportunity detection

Identify decisions that remain available now.

### G. Explanation

Show the user why the system reached a conclusion.

### H. User interaction

Ask the minimum number of questions required to resolve material uncertainty.

Every feature should clearly improve at least one of these responsibilities.

---

## 8. Think Before Asking

Before asking the user a question, search all available context:

- invoices;
- payments;
- receipts;
- purchases;
- calendar;
- mileage;
- projects;
- banking;
- documents;
- prior answers;
- saved financial profile;
- related records;
- historical patterns.

Ask only when:

- the answer materially changes classification, eligibility, calculation, risk, or filing;
- the answer cannot be inferred with sufficient confidence;
- user confirmation is necessary;
- only the user can know the intent or purpose.

Every question should explain why it matters.

Bad:

> Is this business?

Better:

> Was this camera purchased primarily for your production work? This determines whether it should be treated as a business asset, a mixed-use asset, or a personal purchase.

---

## 9. Continuous, Not After-the-Fact

Do not design workflows that wait until tax season to become useful.

When an event happens, evaluate what can be learned immediately.

### When an invoice is issued

- update expected income;
- update accounts receivable;
- associate client and project;
- identify service period;
- check whether related expenses or mileage are missing.

### When payment arrives

- match to invoice;
- update actual cash flow;
- update year-to-date income;
- recalculate estimated taxes;
- detect underpayment risk.

### When equipment is purchased

- identify likely business use;
- determine whether it may be an asset;
- request only missing facts;
- track placed-in-service date;
- compare available treatments;
- update cash-flow and tax projections.

### When a job appears on the calendar

- associate client and project;
- prepare mileage capture;
- look for travel and lodging;
- compare later against invoices and deposits.

### When a tax rule changes

- identify affected users, years, calculations, and recommendations;
- recompute affected scenarios;
- explain what changed.

---

## 10. Calculation and AI Boundaries

### AI may assist with

- interpreting text;
- extracting fields;
- classifying candidate transactions;
- identifying possible relationships;
- generating questions;
- explaining rules;
- spotting likely opportunities;
- summarizing evidence;
- detecting ambiguity.

### Deterministic code must perform

- arithmetic;
- tax tables;
- thresholds;
- phaseouts;
- depreciation;
- basis calculations;
- carryovers;
- allocations;
- form-line calculations;
- reconciliation;
- date rules;
- validation.

### The user decides

- uncertain business purpose;
- material classifications;
- tax elections;
- assumptions only the user can verify;
- final filing positions;
- destructive actions.

Core rule:

> AI reasons. Code calculates. The user decides.

Do not allow a language model to invent or free-write material tax calculations that should come from tested code.

---

## 11. Recommendation Standard

Every material recommendation must identify:

- the proposed action;
- why it matters now;
- expected benefit;
- possible downside;
- cash-flow effect;
- current-year effect;
- possible future-year effect;
- eligibility conditions;
- evidence available;
- missing facts;
- assumptions;
- confidence;
- deadline;
- alternatives;
- exact sources;
- whether professional review is advisable.

A recommendation should be traceable as:

```text
Evidence
  → Facts
  → Relationships
  → Applicable rule
  → Deterministic calculation
  → Alternatives
  → Recommendation
```

---

## 12. Tax Is an Output, Not the Whole Product

Taxes are one major use of the continuously maintained financial state.

The same state should also support:

- current cash position;
- cash-flow forecasting;
- accounts receivable;
- project profitability;
- client profitability;
- equipment ownership;
- debt tracking;
- retirement planning;
- estimated payments;
- business-performance reporting;
- purchase timing;
- savings goals;
- financial risk;
- future planning.

Do not make architecture decisions that force all information into tax-only concepts.

A project, invoice, purchase, or asset must remain useful beyond filing a return.

---

## 13. Time Matters

All financial knowledge and conclusions must be time-aware.

Every applicable record should support:

- event date;
- effective date;
- service period;
- payment date;
- tax year;
- source version;
- rule version;
- calculation version;
- date first known;
- date confirmed;
- date superseded.

Never apply a current-year threshold or rule to a prior year without explicit versioning.

Never assume:

- invoice date equals income-recognition date;
- payment date equals service date;
- purchase date equals placed-in-service date;
- calendar date alone establishes deductibility.

---

## 14. Sources and Authority

Material tax conclusions must use versioned sources.

Prefer:

1. enacted law;
2. Treasury regulations;
3. applicable court authority;
4. official IRS forms and instructions;
5. IRS administrative guidance;
6. official IRS publications and topic pages;
7. official state sources;
8. reputable professional secondary material.

Informal sources may help discover a topic but should not be the final authority.

Each material conclusion should retain:

- source title;
- issuing body;
- jurisdiction;
- tax year;
- effective dates;
- source version;
- retrieval date;
- exact citation;
- affected rule.

Do not say merely:

> According to the IRS.

Identify the actual source.

---

## 15. Confidence and Uncertainty

Do not hide uncertainty.

Use structured confidence such as:

- Confirmed
- High
- Medium
- Low
- Unknown

Confidence should consider:

- evidence quality;
- entity-match quality;
- classification certainty;
- rule clarity;
- source currency;
- calculation certainty;
- unresolved facts.

A critical unknown cannot be averaged away by other high-confidence facts.

Example:

A receipt and bank match may be certain, while business-use percentage remains unknown. The deduction is therefore not confirmed.

---

## 16. User Experience Principles

Financial Brain should feel like a capable financial operator working alongside the user throughout the year.

It should be:

- calm;
- clear;
- fast;
- transparent;
- nonjudgmental;
- proactive without being noisy;
- simple at first glance;
- detailed when requested.

The system should:

- avoid repetitive questions;
- preserve work;
- explain consequences;
- show assumptions;
- distinguish estimates from final numbers;
- bring attention to matters while action is still possible;
- let the user correct the model.

The system should not:

- overwhelm the user with forms;
- turn every transaction into an interview;
- bury important decisions in dashboards;
- claim certainty it does not have;
- make silent irreversible choices.

---

## 17. Event Relevance

Not every event deserves an alert.

Notify the user when:

- action is time-sensitive;
- a deadline is approaching;
- money may be lost;
- a tax opportunity may expire;
- evidence is missing and may become difficult to recover;
- a projected obligation materially changes;
- records conflict;
- cash flow may become insufficient;
- a decision has meaningful alternatives.

Background updates should remain quiet when no user action is required.

---

## 18. Architectural Test for Every Feature

Before adding or changing a feature, answer:

1. What real-world event does this represent?
2. What evidence does it capture or use?
3. Which entities does it identify?
4. Which relationships does it create?
5. How does it change the current financial state?
6. Which calculations must update?
7. Which future questions can now be avoided?
8. Which decisions become possible earlier?
9. How is the conclusion explained?
10. How can the user correct it?
11. What happens to prior conclusions after correction?
12. Is the result useful outside of taxes?

A feature that cannot answer these questions may be isolated UI rather than part of Financial Brain.

---

## 19. Do Not Break

Never:

- destroy original financial evidence;
- merge evidence with conclusions;
- silently overwrite records;
- assume deposits are income;
- assume withdrawals are expenses;
- assume invoices are paid;
- invent business purpose;
- manufacture documentation;
- hide assumptions;
- hide uncertainty;
- apply the wrong tax-year rule;
- choose a material election silently;
- optimize tax while ignoring cash flow and future consequences;
- ask for information already known;
- let AI replace deterministic calculations;
- produce an untraceable recommendation;
- allow UI changes to alter financial logic without tests;
- make tax season the first time the system understands the year.

---

## 20. Definition of Success

Financial Brain succeeds when the user does not need to rebuild their financial history at the end of the year.

By tax time, the system should already know, subject to review:

- what income was earned;
- what was paid;
- what remains receivable;
- which purchases were business-related;
- which purchases became assets;
- which trips had business purpose;
- which documents support each conclusion;
- which facts remain uncertain;
- which elections were considered;
- which planning decisions were made;
- how every result flows into reporting and tax forms.

The tax return should be an output of a financial state that has been maintained all year.

---

## 21. Final Instruction to Every Agent

Do not merely build screens.

Do not merely categorize transactions.

Do not merely complete forms.

Maintain the living financial state.

Use each event to improve context.

Calculate while action is still possible.

Explain every material conclusion.

Preserve the evidence.

Let the user decide.
