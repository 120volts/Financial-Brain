# Naming Note

The product may currently be called Financial Brain, but the architecture should not depend on the word “Brain.”

The central concept is a continuously maintained financial state.

Possible future product or architectural names may change without changing the model described in `AGENTS.md`.

Use neutral internal concepts such as:

- financial state;
- evidence;
- facts;
- relationships;
- calculations;
- projections;
- opportunities;
- decisions.

Avoid renaming the architecture casually until the product name is finalized.
