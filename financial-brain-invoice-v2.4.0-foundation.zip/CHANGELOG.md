# Changelog

All notable changes to the Financial Brain Invoice module are documented here.

## [2.4.0-foundation] - 2026-07-18

### Added
- Production repository foundation.
- `manifest.webmanifest` for installable web-app metadata.
- `service-worker.js` for application-shell caching and offline fallback.
- Dependency-free local development server.
- Baseline automated smoke tests.
- Codex/AI development rules in `AGENTS.md`.
- Product, requirements, architecture, data-model, UI and decision documentation.
- Untouched v2.3.4 baseline under `legacy/v2.3.4`.

### Preserved
- Existing v2.3.4 invoice behavior and localStorage keys.

## [2.3.4] - Baseline

### Fixed
- Pull-down refresh restores all five bottom navigation tabs.
- The New tab restores a fresh usable invoice screen.
- Visible v2.3.4 marker added.
