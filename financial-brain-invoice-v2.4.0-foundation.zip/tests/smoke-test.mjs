import { readFile, access } from 'node:fs/promises';
import assert from 'node:assert/strict';

const html = await readFile(new URL('../app/index.html', import.meta.url), 'utf8');
const requiredFiles = ['manifest.webmanifest','service-worker.js','icon-192.png','icon-512.png'];
for (const file of requiredFiles) await access(new URL(`../app/${file}`, import.meta.url));

for (const feature of [
  'function saveInvoice(',
  'function previewInvoice(',
  'function markViewed(',
  'function markPaid(',
  'function duplicateCurrentInvoice(',
  'function buildInvoicePDF(',
  'function renderClients(',
  'function renderItems(',
  'function renderBrain('
]) assert.ok(html.includes(feature), `Missing baseline feature: ${feature}`);

for (const key of [
  'invoiceApp.invoices',
  'invoiceApp.clients',
  'invoiceApp.items',
  'invoiceApp.brainEvents',
  'invoiceApp.taxRecords'
]) assert.ok(html.includes(key), `Missing storage key: ${key}`);

assert.match(html, /manifest\.webmanifest/);
assert.match(html, /serviceWorker\.register/);
console.log('Smoke tests passed: baseline features and PWA files are present.');
